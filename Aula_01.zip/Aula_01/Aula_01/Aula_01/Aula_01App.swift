//
//  Aula_01App.swift
//  Aula_01
//
//  Created by Turma01-1 on 23/10/24.
//

import SwiftUI

@main
struct Aula_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
