//
//  Instagram.swift
//  Aula_01
//
//  Created by Turma01-1 on 23/10/24.
//

import SwiftUI

struct Instagram: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Instagram()
}
